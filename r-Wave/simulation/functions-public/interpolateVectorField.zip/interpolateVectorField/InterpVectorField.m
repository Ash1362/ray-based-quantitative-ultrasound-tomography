%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%                   Interpolating vector field
%          coded by Manuel A. Diaz @ ENSMA | Pprime, 2021
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Using example from :
% [1] Smolik, Michal, and Vaclav Skala. "Vector field interpolation with
%     radial basis functions." Proceedings of SIGRAD 2016, May 23rd and
%     24th, Visby, Sweden. No. 127. Link-ping University Electronic Press,
%     2016. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear, clc, close all;

% Exact vector field
u_exact = @(x,y) x.*(0.5*x.^2+0.5) + y.*(-x+(0.5*y-1).*y+0.5);
v_exact = @(x,y) 0.5*y.*x.^2 + x.*(-0.5*y.^2+y-0.5)+0.5*y-1.0;

% Source locations
source1=[-1,1]';             % source
source2=[1,1]';              % source
source3=[0.543689,1.83929]'; % saddle
sources=[source1,source2,source3]';

% Visualize the exact sources flow
figure(2); 
[sx,sy] = meshgrid(-2:0.2:2,-1:0.2:3);
streamline(sx,sy,u_exact(sx,sy),v_exact(sx,sy),sx(:),sy(:)); hold on;
scatter(sources(:,1),sources(:,2),'or'); hold off;
title('Exact velocity field');

%% Build initil mesh points %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[x,y] = meshgrid(-2:0.2:2,-1:0.2:3);

% Build initial vector field
u = u_exact(x,y);
v = v_exact(x,y);

% Visualize the initial vector field
h(1)=figure(1); quiver(x,y,u,v); hold on;

%% Build query mesh points %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[xq,yq] = meshgrid(-2:0.1:2,-1:0.1:3);

% Interpolate the field to all query mesh points
uq = interp2(x,y,u,xq,yq,'cubic');
vq = interp2(x,y,v,xq,yq,'cubic');

% Visualize the interpolated vector field
h(2)=quiver(xq,yq,uq,vq); hold off;
title('Interpolated velocity field');

%% Measure comparison to the exact solution 
err_x = norm(u_exact(xq,yq)-uq,1); disp(err_x);
err_y = norm(v_exact(xq,yq)-vq,1); disp(err_y);

figure(3); 
streamline(xq,yq,uq,vq,xq(:),yq(:)); hold on;
scatter(sources(:,1),sources(:,2),'or'); hold off;
title('Interpolated velocity field');